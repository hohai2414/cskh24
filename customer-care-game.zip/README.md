# Customer Care Game

A web-based interactive game for training customer care sales processes.

## Features
- Drag and drop interface for arranging sales steps.
- Timer and score tracking.
- Win/Loss conditions.
- Responsive design.

## How to Run
Simply open `index.html` in your web browser.
